package com.rest.documentation.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.rest.documentation.dao.CarRepository;
import com.rest.documentation.entity.Car;
@Service
public class CarServiceImpl implements CarService {
	@Autowired
	private CarRepository carRepository;
	@Override
	public List<Car> getAllCars() {
		List<Car> list = (List<Car>)carRepository.findAll();
		return list;
	}
	@Override
	public Car getCarById(int id) {
		Car car = null;
		try {
			car = carRepository.findById(id);
		} catch(Exception e){
			e.printStackTrace();
		}
		return car;
	}
	@Override
	public Car addNewCar(Car newCar) {
		Car car = carRepository.save(newCar);
		return car;
	}
	@Override
	public void removeCar(int id) {
		carRepository.deleteById(id);
	}

	@Override
	public void updateCar(Car car, int id) {
		car.setId(id);
		carRepository.save(car);
	}
}
