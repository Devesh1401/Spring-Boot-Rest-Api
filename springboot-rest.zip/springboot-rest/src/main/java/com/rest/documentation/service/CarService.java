package com.rest.documentation.service;

import java.util.List;

import com.rest.documentation.entity.Car;

public interface CarService {
	public List<Car> getAllCars();
	public Car getCarById(int id);
	public Car addNewCar(Car newCar);
	public void removeCar(int id);
	public void updateCar(Car car, int id);
	
}
