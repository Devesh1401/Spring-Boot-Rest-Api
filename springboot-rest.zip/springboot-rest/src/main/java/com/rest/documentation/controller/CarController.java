package com.rest.documentation.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.rest.documentation.entity.Car;
import com.rest.documentation.service.CarService;

@RestController
public class CarController {
	
	@Autowired
	private CarService carService;
	
	@GetMapping("/cars")
	public List<Car> getCars(){
		return carService.getAllCars();
	}
	
	@GetMapping("/cars/{id}")
	public Car getCar(@PathVariable("id") int id) {
		return carService.getCarById(id);
	}
	
	@PostMapping("/cars")
	public Car addCar(@RequestBody Car car) {
		return carService.addNewCar(car);
	}
	
	@DeleteMapping("/cars/{id}")
	public void removeCar(@PathVariable("id") int id) {
		carService.removeCar(id);
	}
	
	@PutMapping("cars/{id}")
	public void updateCar(@RequestBody Car car, @PathVariable("id") int id) {
		carService.updateCar(car, id);
	}
}
