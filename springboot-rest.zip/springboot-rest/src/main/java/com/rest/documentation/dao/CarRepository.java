package com.rest.documentation.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.rest.documentation.entity.Car;

@Repository
public interface CarRepository extends CrudRepository<Car,Integer>{

	public Car findById(int id);
	
}
